package com.pepkor.api.controller;

import com.pepkor.api.modal.Role;
import com.pepkor.api.modal.User;
import com.pepkor.api.modal.WorkItem;
import com.pepkor.api.service.UserService;
import com.pepkor.api.service.WorkItemService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.core.MediaType;

@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private WorkItemService workItemService;

      
    @PostMapping("/api/kanban/workitem")
    @Consumes(MediaType.APPLICATION_JSON)
    public ResponseEntity<?> createWorkItem(@RequestBody WorkItem workItem){
    	workItemService.saveWorkItem(workItem);
         return new ResponseEntity<>(workItem, HttpStatus.CREATED);
    }
    
    @PutMapping("/api/kanban/workitem-update")
    public ResponseEntity<?> updateWorkItem(@RequestBody WorkItem workItem){
        return new ResponseEntity<>(workItemService.updateWorkItem(workItem), HttpStatus.CREATED);
    }

    @GetMapping("/api/kanban/getallworkitemsbystatus")
    public ResponseEntity<?> getAllWorkItemsByStatus(@RequestBody WorkItem workItem){
        return new ResponseEntity<>(workItemService.findAllWorkItemByStatus(workItem), HttpStatus.OK);
    }
    
    @GetMapping("/api/kanban/getallworkitems")
    public ResponseEntity<?> getAllWorkItems(){
    	return new ResponseEntity<>(workItemService.findAllWorkItems(), HttpStatus.OK);
    }
    
    @GetMapping("/api/kanban/getallusers")
    public ResponseEntity<?> getAllUsers(){
    	return new ResponseEntity<>(userService.findAllUsers(), HttpStatus.OK);
    }
    
    @GetMapping("/api/kanban/getfiveworkitemsbystatus")
    public ResponseEntity<?> fiveWorkItemsByStatus(){
    	String status = "InProgress";
        return new ResponseEntity<>(workItemService.fiveWorkItemsByStatus(status), HttpStatus.OK);
    }
}
