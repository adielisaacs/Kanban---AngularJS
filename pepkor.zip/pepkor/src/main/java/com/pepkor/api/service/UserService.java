package com.pepkor.api.service;

import com.pepkor.api.modal.User;

import java.util.List;

public interface UserService {
    User saveUser(User user);

    User updateUser(User user);

    void deleteUser(Long userId);

    List<User> findAllUsers();

    Long numberOfUsers();
}
