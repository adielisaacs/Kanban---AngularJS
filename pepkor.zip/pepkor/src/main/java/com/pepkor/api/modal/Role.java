package com.pepkor.api.modal;

public enum Role {
    USER, ADMIN
}

