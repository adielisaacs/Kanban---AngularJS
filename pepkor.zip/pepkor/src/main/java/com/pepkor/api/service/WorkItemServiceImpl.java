package com.pepkor.api.service;

import com.pepkor.api.modal.WorkItem;
import com.pepkor.api.repository.WorkItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional //It is not necessary. You can use it, if you have multiple database operation in a single service method.
public class WorkItemServiceImpl implements WorkItemService {

    @Autowired
    private WorkItemRepository workItemRepository;
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public WorkItem saveWorkItem(WorkItem workitem){
        return workItemRepository.save(workitem);
    }
    
    @Override
    public WorkItem updateWorkItem(WorkItem workitem){
        return workItemRepository.save(workitem);
    }
   
    @Override
    public List<WorkItem> fiveWorkItemsByStatus(String status){
    	 return jdbcTemplate.query("select * from workitem where status=? limit 5", new Object[] {
 	    		status
 	        },
 	        new BeanPropertyRowMapper <WorkItem> (WorkItem.class));
    }
    
    public List<WorkItem> findAllWorkItems(){
    	return workItemRepository.findAll();
    }
	
	public List<WorkItem> findAllWorkItemByStatus(WorkItem workitem){
		
	    return jdbcTemplate.query("select * from workitem where status=?", new Object[] {
	    		workitem.getStatus()
	        },
	        new BeanPropertyRowMapper <WorkItem> (WorkItem.class));
	}

}
