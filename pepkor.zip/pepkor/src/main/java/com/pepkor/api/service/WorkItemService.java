package com.pepkor.api.service;

import com.pepkor.api.modal.WorkItem;

import java.util.List;

public interface WorkItemService {
	
    WorkItem saveWorkItem(WorkItem workitem);
    
    WorkItem updateWorkItem(WorkItem workitem);

    List<WorkItem> findAllWorkItemByStatus(WorkItem workitem);
    
    List<WorkItem> findAllWorkItems();
    
    List<WorkItem> fiveWorkItemsByStatus(String status);
}
