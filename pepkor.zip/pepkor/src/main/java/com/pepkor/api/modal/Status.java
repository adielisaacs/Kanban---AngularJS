package com.pepkor.api.modal;

public enum Status {
	Todo, InProgress, Done
}



