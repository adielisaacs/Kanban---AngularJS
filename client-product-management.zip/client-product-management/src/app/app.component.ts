import { Component} from '@angular/core';
import {AdminService} from './services/admin.service';
import {Role} from './model/role';
import {Router, RoutesRecognized} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{
  title = 'Pepkor Kanban Board';
  isAdminPanel: boolean = true;

}
