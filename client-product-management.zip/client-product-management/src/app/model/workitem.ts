import {Status} from './status';
import {User} from './user';
export class WorkItem {
  id:number;
  status: Status;
  user: User;
  title: string="";
  description: string="";
}
