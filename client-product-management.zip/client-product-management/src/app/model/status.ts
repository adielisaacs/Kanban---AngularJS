export enum Status {
  DONE = 'Done',
  TODO = 'Todo',
  INPROGRESS = 'InProgress'
}
