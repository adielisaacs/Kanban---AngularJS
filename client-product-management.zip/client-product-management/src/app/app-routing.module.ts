import { NgModule } from '@angular/core';
import { Router, Routes, RouterModule } from '@angular/router';
import {DashboardComponent} from './components/admin/dashboard/dashboard.component';
import {UserListComponent} from './components/admin/user-list/user-list.component';
import {WorkItemListComponent} from './components/admin/workitem-list/workitem-list.component';
import {UnathorizedComponent} from './components/error/unathorized/unathorized.component';
import {NotFoundComponent} from './components/error/not-found/not-found.component';
const routes: Routes = [
  //Main page
  {path: '', redirectTo: 'dashboard', pathMatch: 'full'},
  //admin panel
  {path: 'dashboard',
  component: DashboardComponent
  },
  {path: 'user-list',
  component: UserListComponent
  },
  {path: 'workitem-list',
  component: WorkItemListComponent
 },
  //error pages
  {path: '404', component: NotFoundComponent},
  {path: '401', component: UnathorizedComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
constructor(private router: Router) {
  this.router.errorHandler = (error: any) => {
    this.router.navigate(['/404']);
  }
}
}
