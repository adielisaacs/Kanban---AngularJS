import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs';
import {from} from 'rxjs';
import {map} from 'rxjs/operators';
import {User} from '../model/user';
import {Role} from '../model/role';
import {Status} from '../model/status';
import {WorkItem} from '../model/workitem';

let API_URL = "http://localhost:8080/api/kanban/";

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  headers: HttpHeaders;

  constructor(private http: HttpClient) {
    this.headers = new HttpHeaders({"Content-Type":"application/json","content-type":"application/json",  "Access-Control-Allow-Headers": "content-type",
                                        "Access-Control-Allow-Methods": "GET, POST, OPTIONS, PUT, PATCH, DELETE",
                                        "Access-Control-Allow-Origin": "http://localhost:8080"});
  }

  numberOfUsers(): Observable<any> {
      return this.http.get(API_URL + "getallusers",
      {headers: this.headers});
  }
findAllUsers(): Observable<any> {
                  return this.http.get(API_URL + "getallusers",
                  {headers: this.headers});
              }
  //WorkItem
  createWorkItem(workitem: WorkItem): Observable<any> {
    return this.http.post(API_URL + "workitem", JSON.stringify(workitem),
  {headers: this.headers});
  }

  updateWorkItem(workitem: WorkItem): Observable<any> {
    return this.http.put(API_URL + "workitem-update", JSON.stringify(workitem),
  {headers: this.headers});
  }

  getAllWorkItem(): Observable<any> {
    return this.http.get(API_URL + "getallworkitems",
  {headers: this.headers});
  }

  getWorkItemByStatus(workitem: WorkItem): Observable<any> {
    return this.http.post(API_URL + "getallworkitemsbystatus", JSON.stringify(workitem),
  {headers: this.headers});
  }

  getFiveWorkItem(): Observable<any> {
      return this.http.get(API_URL + "getfiveworkitemsbystatus", {headers: this.headers});
    }

}
