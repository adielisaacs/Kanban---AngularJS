import { Component, OnInit, ViewChild } from '@angular/core';
import{ AdminService} from '../../../services/admin.service';
import {WorkItem} from '../../../model/workitem';
import {User} from '../../../model/user';
import {MatPaginator, MatTableDataSource, MatSort} from '@angular/material';

declare var $: any;

@Component({
  selector: 'app-workitem-list',
  templateUrl: './workitem-list.component.html',
  styleUrls: ['./workitem-list.component.css']
})
export class WorkItemListComponent implements OnInit {
  workitemList: Array<WorkItem>;
  fiveworkitemList:Array<WorkItem>;
  dataSource: MatTableDataSource<WorkItem> = new MatTableDataSource();
  dataSource2: MatTableDataSource<WorkItem> = new MatTableDataSource();
  displayedColumns: string[] = ['id', 'name', 'status', 'title','description'];
  selectedWorkItem: WorkItem = new WorkItem();
  errorMessage: string;
  infoMessage: string;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private adminService: AdminService) { }

  ngOnInit() {
    this.findAllWorkItem();
    this.fiveWorkItem();
  }

  ngAfterViewInit(){
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;

  }

  findAllWorkItem(){
    this.adminService.getAllWorkItem().subscribe(data => {
      this.workitemList = data;
      this.dataSource.data = this.workitemList;
    });
  }

  createNewWorkItemRequest(){
    this.selectedWorkItem = new WorkItem();
      this.selectedWorkItem.user = new User();
    $('#workitemModal').modal('show');
  }

  editWorkItemRequest(workitem: WorkItem){
    this.selectedWorkItem = workitem;
    $('#workitemModal').modal('show');
  }

  saveWorkItem(){
    if(!this.selectedWorkItem.id){
      this.createWorkItem();
    }else{
      this.updateWorkItem();
    }
  }

  createWorkItem(){
    this.adminService.createWorkItem(this.selectedWorkItem).subscribe(data => {
      this.workitemList.push(data);
      this.dataSource = new MatTableDataSource(this.workitemList);
      this.infoMessage = "Mission is completed";
      $('#workitemModal').modal('hide');
    },err => {
      this.errorMessage = "Unexpected error occurred.";
    });
  }

  updateWorkItem(){
    this.adminService.updateWorkItem(this.selectedWorkItem).subscribe(data => {
      let itemIndex = this.workitemList.findIndex(item => item.id == this.selectedWorkItem.id);
      this.workitemList[itemIndex] = this.selectedWorkItem;
      this.dataSource = new MatTableDataSource(this.workitemList);
      this.infoMessage = "Mission is completed";
      $('#workitemModal').modal('hide');
    },err => {
      this.errorMessage = "Unexpected error occurred.";
    });
  }
}
