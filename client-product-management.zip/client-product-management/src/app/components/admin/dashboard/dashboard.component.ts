import { Component, OnInit } from '@angular/core';
import { count } from 'rxjs/operators';
import {AdminService} from '../../../services/admin.service';
import {WorkItem} from '../../../model/workitem';
import {User} from '../../../model/user';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  workitemList: Array<WorkItem>;
  userList: Array<User>;
  userCount:any;
  workitemCount:any ;

  constructor(private adminService: AdminService) {
  this.workitemList = [];
  this.userList = [];
    this.userCount = 0;
    this.workitemCount = 0;
   }

  ngOnInit() {
    this.numberOfUsers();
    this.numberOfWorkItems();
  }

  numberOfUsers(){
    this.adminService.numberOfUsers().subscribe(data => {
      this.userList = data;
    });
  }

  numberOfWorkItems(){
    this.adminService.getAllWorkItem().subscribe(data => {
      this.workitemList = data;
    });
  }


}
